#pragma once

#include <iostream>
#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <fstream>
#include <vector>

#include "Camera.h"

class Terrain {

public:

	void findNormal() {
		// Estimate normals for interior nodes using central difference.
		float invTwoDX = 1.0f / (2.0f * 1.0f);
		float invTwoDZ = 1.0f / (2.0f * 1.0f);
		for (int i = 2; i < (int)textureSize.y; ++i)
		{
			for (int j = 2; j < (int)textureSize.x; ++j)
			{
				float t = heightData[(i - 1) * (int)textureSize.x + j];
				float b = heightData[(i + 1) * (int)textureSize.x + j];
				float l = heightData[i * (int)textureSize.x + j - 1];
				float r = heightData[i * (int)textureSize.x + j + 1];

				glm::vec3 tanZ(0.0f, (t - b) * invTwoDZ, 1.0f);
				glm::vec3 tanX(1.0f, (r - l) * invTwoDX, 0.0f);

				glm::vec3 N;
				N = glm::cross(tanZ, tanX);
				glm::normalize(N);

				terrainNorms[(i - 2) * (int)textureSize.x + (j - 2)] = N;
			}
		}
	}

	float width()const
	{
		return (textureSize.x - 1) * 1;
	}

	float depth()const
	{
		return (textureSize.y - 1) * 1;
	}

	float getHeight(float x, float z)const
	{
		try {
			// Transform from terrain local space to "cell" space.
			float c = (x + 0.5f * width()) / 1;
			float d = (z - 0.5f * depth()) / -1;

			// Get the row and column we are in.
			int row = (int)floorf(d);
			int col = (int)floorf(c);

			if (row >= 0 && col >= 0) {

				// Get the heights of the cell we are in.
				float A = heightData[row * (int)textureSize.x + col];
				float B = heightData[row * (int)textureSize.x + col + 1];
				float C = heightData[(row + 1) * (int)textureSize.x + col];
				float D = heightData[(row + 1) * (int)textureSize.x + col + 1];

				// Where we are relative to the cell.
				float s = c - (float)col;
				float t = d - (float)row;

				// If upper triangle ABC.
				if (s + t <= 1.0f)
				{
					float uy = B - A;
					float vy = C - A;
					return A + s * uy + t * vy;
				}
				else // lower triangle DCB.
				{
					float uy = C - D;
					float vy = B - D;
					return D + (1.0f - s) * uy + (1.0f - t) * vy;
				}
			}
			else {
				return 0;
			}
		}
		catch (...) {
			return 0;
		}
	}

	void Initalise(camera* _cam, std::string _pathToHeightMap) {

		camTerrain = _cam;


		float heightScale = 0.5f;


		//Create Vertcies and Indices


		int totalSize = 0;

		//Get Info From Map
		ifstream heightMap;
		heightMap.open(_pathToHeightMap.c_str(), std::ios_base::binary);
		if (heightMap.fail())
		{
			return;
		}
		else {
			//Get Image Size
			int c = 0;
			int w, h, f = 0;

			unsigned char* image = SOIL_load_image
			(
				_pathToHeightMap.c_str(),
				&w, &h, 0,
				SOIL_LOAD_L
			);

			if (image == nullptr) {
				w = 513;
				h = 513;
			}

			totalSize = w * h;

			//Resize vectors to image size

			rawData.resize(totalSize);
			heightData.resize(totalSize * 2);

			textureSize.x = sqrt(rawData.size());
			textureSize.y = textureSize.x;

			heightMap.close();

			heightMap.open(_pathToHeightMap.c_str(), std::ios_base::binary);

			//Put map info into vector

			heightMap.read((char*)&rawData[0], (std::streamsize)rawData.size());
		}

		heightMap.close();


		for (int i = 0; i < rawData.size(); ++i)
		{
			heightData[i] = (float)rawData[i] * heightScale;
		}

		int row = 0;
		int col = 0;


		float halfWidth = (textureSize.x - 1) * 1.0f * 0.5f;
		float halfDepth = (textureSize.y - 1) * 1.0f * 0.5f;

		float du = 1.0f / (textureSize.x - 1);
		float dv = 1.0f / (textureSize.y - 1);

		terrainNorms.resize(totalSize + 1);
		int inter = 0;
		findNormal();

		collisionInfo.resize((int)textureSize.y);
		for (size_t i = 0; i < collisionInfo.size(); i++)
		{
			collisionInfo.at(i).resize((int)textureSize.x);
		}

		for (int i = 0; i < textureSize.y - 1; ++i)
		{
			float z = halfDepth - i * 1.0f;
			for (int j = 0; j < textureSize.x; ++j)
			{

				float x = -halfWidth + j * 1.0f;
				float y = heightData[i * (int)textureSize.x + j];


				//Positions
				terrainVerts.push_back(x);
				terrainVerts.push_back(y);
				terrainVerts.push_back(z);

				//Normal
				terrainVerts.push_back(terrainNorms[inter].x);
				terrainVerts.push_back(terrainNorms[inter].y);
				terrainVerts.push_back(terrainNorms[inter].z);

				inter++;

				//Stretch texture over grid.
				terrainVerts.push_back(j * du);
				terrainVerts.push_back(i * dv);

			}
		}

		//Create Indices

		// Iterate over each quad and compute indices.

		terrainIndices.resize(totalSize * 6);

		int k = 0;
		for (int i = 0; i < (int)textureSize.y - 1; ++i) {
			for (int j = 0; j < (int)textureSize.x - 1; ++j) {
				terrainIndices[k] = i * (int)textureSize.x + j;
				terrainIndices[k + 1] = i * (int)textureSize.x + j + 1;
				terrainIndices[k + 2] = (i + 1) * (int)textureSize.x + j;

				terrainIndices[k + 3] = (i + 1) * (int)textureSize.x + j;
				terrainIndices[k + 4] = i * (int)textureSize.x + j + 1;
				terrainIndices[k + 5] = (i + 1) * (int)textureSize.x + j + 1;

				k += 6; // next quad
			}
		}


		//bind buffers

		glGenTextures(1, &texture);
		glBindTexture(GL_TEXTURE_2D, texture);

		int width, height;

		unsigned char* image = SOIL_load_image("Assets/Textures/dirt.png", &width, &height, 0, SOIL_LOAD_RGBA);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glGenerateMipmap(GL_TEXTURE_2D);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		SOIL_free_image_data(image);
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_BLEND);

		glGenVertexArrays(1, &VAO);
		glBindVertexArray(VAO);

		glGenBuffers(1, &VBO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, terrainVerts.size() * sizeof(GLfloat), &terrainVerts[0], GL_STATIC_DRAW);

		glGenBuffers(1, &EBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, terrainIndices.size() * sizeof(GLuint), &terrainIndices[0], GL_STATIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
		glEnableVertexAttribArray(2);

		//Create program
		program = ShaderLoader::CreateProgram("Assets/shader/Terrain.vs", "Assets/shader/Terrain.fs");
	}

	void Render(camera* camera) {

		glUseProgram(program);
		glBindVertexArray(VAO);

		glm::mat4 model;
		glm::mat4 translationMatrix = glm::translate(glm::mat4(), position);
		glm::mat4 rotationZ = glm::rotate(glm::mat4(), glm::radians(rotationAngle), rotationAxisZ);
		glm::mat4 scaleMatrix = glm::scale(glm::mat4(), scale);
		model = translationMatrix * rotationZ * scaleMatrix;
		glm::mat4 mvp = camera->getProj() * camera->getView() * model;
		glm::vec3 camPos = camera->getPos();

		glm::mat4 projCalc = camera->getProj() * camera->getView() * model;

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture);

		glUniform1i(glGetUniformLocation(program, "texture_diffuse1"), 0);

		GLint mvpLoc = glGetUniformLocation(program, "proj_calc");
		glUniformMatrix4fv(mvpLoc, 1, GL_FALSE, glm::value_ptr(projCalc));
		GLint modelPass = glGetUniformLocation(program, "model");
		glUniformMatrix4fv(modelPass, 1, GL_FALSE, glm::value_ptr(model));
		GLint camPosPass = glGetUniformLocation(program, "camPos");
		glUniformMatrix3fv(camPosPass, 1, GL_FALSE, glm::value_ptr(camPos));

		glDrawElements(GL_TRIANGLES, terrainIndices.size(), GL_UNSIGNED_INT, 0);
		glDisable(GL_CULL_FACE);
		glDisable(GL_BLEND);

		//Clearing the vertex array
		glBindVertexArray(0);
		glUseProgram(0);

	}

	vector<vector<float>> collisionInfo;
	glm::vec3 position = glm::vec3(0.0f, -150.0f, 0.0f);

private:
	glm::mat4 model;
	glm::mat4 projCalc;
	glm::mat4 rotationZ;

	glm::vec3 scale = glm::vec3(1.0f, 1.0f, 1.0f);
	glm::vec2 textureSize;
	glm::vec3 rotationAxisZ = glm::vec3(1.0f, 0.0f, 0.0f);

	vector<unsigned char> rawData;
	vector<float> heightData;
	vector<GLfloat> terrainVerts;
	vector<GLuint> terrainIndices;
	vector<glm::vec3> terrainNorms;


	camera* camTerrain = nullptr;
	GLuint VAO = NULL;
	GLuint VBO = NULL;
	GLuint EBO = NULL;
	GLuint texture = NULL;
	GLuint image = NULL;
	GLuint program = NULL;

	float rotationAngle = 0;

};