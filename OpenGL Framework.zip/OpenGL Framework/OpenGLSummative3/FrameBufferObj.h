#pragma once
#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include <iostream>
#include <time.h>
#include <vector>
#include <windows.h>
#include <cstdlib>
#include <fmod.hpp>
#include "ShaderLoader.h"


class FrameBufferObj {

public:

	void init();
	void initRenderBuffer();

	unsigned int textureColorbuffer;
	unsigned int framebuffer;
	unsigned int rbo;

};