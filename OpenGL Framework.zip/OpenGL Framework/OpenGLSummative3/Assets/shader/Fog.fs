#version 330 core

in vec3 fragPos;
in vec3 fragNormal;
in vec2 fragCoord;

out vec4 color;

uniform sampler2D tex0;
uniform vec3 ambientColor = vec3(0.5, 0.5f, 0.5f);
uniform vec3 lightColor = vec3(0.0f,1.0f,0.0f);
uniform vec3 lightPos = vec3(-2, 6, 3);
uniform vec3 cam = vec3(0, 0, 10);
uniform float lightSpecularStrength = 1.0f;
uniform float shininess = 32.0f;

uniform float fogStart = 5.0f;
uniform float fogRange = 10.0f;
uniform vec4 fogColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);

void main(void)
{
	// Light Direction
	vec3 norm = normalize(fragNormal);
	vec3 lightDir = normalize(fragPos - lightPos);

	// Diffuse Colouring
	float diffuseStrength = max(dot(norm, -lightDir), 0.0f);
	vec3 diffuse = diffuseStrength * lightColor;
	
	// Specular Highlight
	vec3 negViewDir = normalize(cam - fragPos);

	vec3 halfwayVec = normalize(negViewDir - lightDir);
	float specularStrength = pow(max(dot(norm, halfwayVec), 0.0f), shininess);
	vec3 specular = lightSpecularStrength * specularStrength * lightColor;

	vec3 res = ambientColor + diffuse + specular;
	color = vec4(res, 1) * texture(tex0, fragCoord);

    // Linear Fog
    float d = distance(fragPos, cam);
    float e = (d - fogStart) / fogRange;
    float f = clamp(e, 0, 1);
    color = mix(color, fogColor, f);
}
