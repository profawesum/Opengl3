#version 330 core

out vec4 color;

void main(void)
{
    color = vec4(0.0, 0.8f, 1.0, 1.0);
}