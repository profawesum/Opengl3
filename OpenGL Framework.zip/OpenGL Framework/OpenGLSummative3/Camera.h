#pragma once
#include "glm.hpp"
#include "gtc/matrix_transform.hpp"
#include "gtc/type_ptr.hpp"
#include <freeglut.h>


class camera
{
public:
	camera();
	~camera();



	void initCamera();
	void calculate(GLfloat currentTime);
	glm::mat4 Model(glm::vec3 postion, glm::vec3 scale, glm::mat4 rotationZ);
	glm::mat4 getView();
	glm::mat4 getProj();
	glm::vec3 getPos();

	glm::mat4 MVP(glm::vec3 postion, glm::vec3 scale, glm::mat4 rotationZ);

	glm::mat4 SetProj(glm::mat4 project);
	glm::vec3 setCamPos(glm::vec3 pos);

	void rotate(GLfloat currentTime);

	glm::vec3 getCamTarget();
	glm::vec3 getCamUpDir();
	glm::vec3 getCamLookDir();




private:

	glm::vec3 camUpDir;
	glm::vec3 camTar;
	glm::vec3 camPos;
	glm::vec3 camLookDir = glm::vec3(0.0f, 0.0f, 1.0f);;


	glm::mat4 rotMat;
	glm::mat4 rotMat2;

	glm::vec4 newPos;

	glm::mat4 proj;

	glm::mat4 view;


};

extern camera* currentCamera;
