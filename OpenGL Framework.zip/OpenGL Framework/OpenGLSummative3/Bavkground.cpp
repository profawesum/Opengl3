#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include <iostream>
#include <time.h>
#include <vector>
#include <windows.h>
#include <cstdlib>
#include <fmod.hpp>
#include "ShaderLoader.h"

#include "glm.hpp"
#include "gtc/matrix_transform.hpp"
#include "gtc/type_ptr.hpp"
#include "Bavkground.h"
#include "camera.h"
#include "textureloader.h"


LoadTexture texLoad;
camera cam;

glm::mat4 proj;
GLuint texturebg; 
GLuint VBOe1;
GLuint VAOe1;
GLuint EBOe1;
GLuint programBG;
GLuint bg;

glm::vec3 rotationAxisZbg = glm::vec3(1.0f, 0.0f, 0.0f);
float rotationAnglebg = 0;
glm::mat4 rotationZbg = glm::rotate(glm::mat4(), glm::radians(rotationAnglebg), rotationAxisZbg);

GLfloat vertices2[] //bg
{	//pos                    //colour
	-1.0f,	-1.0f,	1.0f,    0.0f, 0.0f, 1.0f,		0.0f, 1.0f,//bot left
	1.0f,	-1.0f,	-1.0f,    1.0f, 0.0f, 0.0f,		1.0f, 0.0f,// top right
	-1.0f,	-1.0f,	-1.0f,    0.0f, 1.0f, 0.0f,		0.0f, 0.0f, //top left
	1.0f,	-1.0f,	1.0f,	 0.0f, 1.0f, 0.0f,		1.0f, 1.0f, //bot right
};

GLuint indices2[] =
{
	0,1,2,	//1 
	0,3,1,	//2
};

void background::backgroundInit()
{
	programBG = ShaderLoader::CreateProgram("Assets/shader/Fog.vs", "Assets/shader/Fog.fs");

	glGenVertexArrays(1, &VAOe1);
	glBindVertexArray(VAOe1);

	glGenBuffers(1, &EBOe1);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOe1);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW);

	glGenBuffers(1, &VBOe1);
	glBindBuffer(GL_ARRAY_BUFFER, VBOe1);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glActiveTexture(GL_TEXTURE3);
	bg = texLoad.loadTexture("Assets/Textures/spaceShips_007.png");
	glBindTexture(GL_TEXTURE_2D, bg);
	glUniform1i(glGetUniformLocation(programBG, "tex"), 3);

}

void background::renderBackground()
{

	glm::vec3 e1pos = glm::vec3(0.0f, 0.0f, 1.0f);
	glm::vec3 e1scale = glm::vec3(1.0f, 1.0f, 1.0f);

	glm::mat4 Proj_calc = cam.MVP(e1pos, e1scale, rotationZbg);
	glm::mat4 enemyModel = cam.Model(e1pos, e1scale, rotationZbg);

	glUseProgram(programBG);

	GLuint mvpLoc3 = glGetUniformLocation(programBG, "proj_calc");
	glUniformMatrix4fv(mvpLoc3, 1, GL_FALSE, glm::value_ptr(Proj_calc));

	GLuint eModelLoc = glGetUniformLocation(programBG, "model");
	glUniformMatrix4fv(eModelLoc, 1, GL_FALSE, glm::value_ptr(enemyModel));

	glBindVertexArray(VAOe1);
	glBindTexture(GL_TEXTURE_2D, bg);

	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
	glBindVertexArray(0);
	glUseProgram(0);

}
