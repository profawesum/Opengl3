#include "Particle.h"
#include "Manager.h"

#include <iostream>

Particle::Particle(vec3 origin, vec3 velocity, float elapsedTime, float speed, float id, camera cam)
{
	this->position = origin;
	this->velocity = velocity;
	this->elapsedTime = elapsedTime;
	this->speed = speed;
	this->id = id;
}

void Particle::update(float dt)
{
	this->velocity.y += -0.2 * .0167f;
	this->position += velocity;
	this->elapsedTime -= .000167;
	//if it has reached the end of its time
	if (this->elapsedTime <= 0.0f) {
		this->position = this->origin;
		this->velocity = glm::vec3(0.25 * cos(this->id * .0167) + 0.25f * utils::randomFloat() - 0.125f, 1.5f + 0.25f * utils::randomFloat() - 0.125f, 0.25 * sin(this->id* .0167) + 0.25f * utils::randomFloat() - 0.125f);
		this->elapsedTime = utils::randomFloat() + 0.125;
	}
	//std::cout << this->position.y << std::endl;
}

vec3 Particle::getPosition()
{
	return this->position;;
}
