#pragma once

#include <glew.h>
#include <glm.hpp>
#include "Camera.h"

using namespace glm;

class Particle {

public:

	Particle(vec3 origin, vec3 velocity, float elapsedTime, float speed, float id, camera cam);

	void update(float dt);

	vec3 getPosition();

	vec3 position;
	vec3 velocity;
	float elapsedTime;
	float speed;

	vec3 origin;

	float id;

private:

	camera* cameraParticle;
};
