#pragma once
#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include <iostream>
#include <time.h>
#include <vector>
#include <windows.h>
#include <cstdlib>
#include <fmod.hpp>

#include "glm.hpp"
#include "gtc/matrix_transform.hpp"
#include "gtc/type_ptr.hpp"

class GeometryModel {


public:
	void initGeometry();
	void Render();
	void setPosition(glm::vec3 position);

	glm::vec3 geomPosition;
	GLuint postProcessShader;


	GLuint VAO, VBO, EBO;

};