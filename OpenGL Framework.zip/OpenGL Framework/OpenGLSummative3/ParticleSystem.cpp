#include "ParticleSystem.h"
#include "ShaderLoader.h"
#include "TextureLoader.h"
#include "Manager.h"

#include <iostream>

camera camParticle;
LoadTexture textureLoader;

using namespace glm;

ParticleSystem::ParticleSystem(glm::vec3 origin)
{
	nParticles = 4000;

	for (int i = 0; i < nParticles; i++) {

		vPosition.push_back(glm::vec3(0.0));
		Particle p = Particle(origin, glm::vec3(0.25f * cos(i * .0167f) + 0.25f * utils::randomFloat() - 0.125f, 2.0f + 0.25f * utils::randomFloat() - 0.125f, 0.25f * sin(i* .0167f) + 0.25f * utils::randomFloat() - 0.125f), utils::randomFloat() + 1.0f, 1.0f, i, camParticle);
		particles.push_back(p);

	}

	program = ShaderLoader::CreateProgram("Assets/shader/ParticleSystem.vs", "Assets/shader/ParticleSystem.fs", "Assets/shader/ParticleSystem.gs");

	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glGenVertexArrays(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * vPosition.size(), &vPosition[0], GL_STATIC_DRAW);

	texture = textureLoader.loadTexture("Assets/Textures/RedPng.png");
	glBindTexture(GL_TEXTURE_2D, texture);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void ParticleSystem::render(float dt)
{
	for (int i = 0; i < nParticles; i++) {
		particles[i].update(0.0167f);
		vPosition[i] = particles[i].getPosition();
	}

	mat4 viewMat = camParticle.getView();
	vec3 vQuad1, vQuad2;

	glm::vec3 vView = camParticle.getCamLookDir();
	vView = glm::normalize(vView);

	vQuad1 = glm::cross(vView, camParticle.getCamUpDir());
	vQuad1 = glm::normalize(vQuad1);

	vQuad2 = glm::cross(vView, vQuad1);
	vQuad2 = glm::normalize(vQuad2);


	glUseProgram(program);

	glUniform3f(glGetUniformLocation(program, "vQuad1"), vQuad1.x, vQuad1.y, vQuad1.z);

	glUniform3f(glGetUniformLocation(program, "vQuad2"), vQuad2.x, vQuad2.y, vQuad2.z);

	glm::mat4 vp = camParticle.getProj() * camParticle.getView();
	glUniformMatrix4fv(glGetUniformLocation(program, "vp"), 1, GL_FALSE, value_ptr(vp));

	glActiveTexture(GL_TEXTURE0);
	glUniform1i(glGetUniformLocation(program, "Texture"), 0);
	glBindTexture(GL_TEXTURE_2D, texture);

	glEnable(GL_BLEND);
	glDepthMask(GL_FALSE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*vPosition.size(), &vPosition[0], GL_STATIC_DRAW);

	glBindVertexArray(vao);
	glDrawArrays(GL_POINTS, 0, nParticles);

	glBindVertexArray(0);

	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);

	//std::cout << "Ended rendering the particles" << std::endl;
}
